close all
clear all
clc
%Cargamos dos imagenes
im1=imread('inv.jpg'); %Imagen de referencia
ima=imread('ver.jpg'); %Imagen a ecualizar

R=size(im1,1);
C=size(im1,2);
                        %Calculamos las dimensiones de ambas imágenes
Ra=size(ima,1);
Ca=size(ima,2);

og_hist=histogcol(im1,R,C); %Calculamos el histograma de la imagen de referencia a color
og_hist_R=og_hist(1,:);
og_hist_G=og_hist(2,:);     %Dividimos el histograma en vectores, por color
og_hist_B=og_hist(3,:);

og_cdf_R=cudf(og_hist_R);
og_cdf_G=cudf(og_hist_G);   %Calculo de la CDF por color de la referencia
og_cdf_B=cudf(og_hist_B);

og_cdf_R=equ(og_cdf_R,R,C);
og_cdf_G=equ(og_cdf_G,R,C); %Ecualizamos las CDF de la referencia
og_cdf_B=equ(og_cdf_B,R,C);

og_cdf_RGB=[og_cdf_R; og_cdf_G; og_cdf_B]; %Juntamos las CDFs 



og_hist_a=histogcol(ima,Ra,Ca); %Calculamos el histograma de la imagen a ecualizar a color
og_hist_a_R=og_hist_a(1,:);
og_hist_a_G=og_hist_a(1,:);     %Dividimos el histograma en vectores, por color
og_hist_a_B=og_hist_a(3,:);

og_cdf_a_R=cudf(og_hist_a_R);
og_cdf_a_G=cudf(og_hist_a_G);   %Calculo de la CDF por color de la imagen a ecualizar
og_cdf_a_B=cudf(og_hist_a_B);

og_cdf_a_R=equ(og_cdf_a_R,Ra,Ca);
og_cdf_a_G=equ(og_cdf_a_G,Ra,Ca);       %Ecualizamos las CDF de la imagen a ecualizar
og_cdf_a_B=equ(og_cdf_a_B,Ra,Ca);

p_1=histmatch(og_cdf_a_R,og_cdf_R);
p_2=histmatch(og_cdf_a_G,og_cdf_G);     %Hacemos matching por color de las CDFs
p_3=histmatch(og_cdf_a_B,og_cdf_B);

ppp=[p_1;p_2;p_3];      %Juntamos la cdf matcheada

im2=transfcol(ima,ppp,Ra,Ca); %Hacemos la transformación respecto a la CDF matcheada
im3=uint8(im2); %Convertimos en uint para visualización

%Hacemos los cálculos de histograma y CDF de la nueva imagen a color
og_hist_eq=histogcol(im3,Ra,Ca);

og_hist_eq_R=og_hist_eq(1,:);
og_hist_eq_G=og_hist_eq(1,:);
og_hist_eq_B=og_hist_eq(3,:);

og_cdf_eq_R=cudf(og_hist_eq_R);
og_cdf_eq_G=cudf(og_hist_eq_G);
og_cdf_eq_B=cudf(og_hist_eq_B);

og_cdf_eq_R=equ(og_cdf_eq_R,Ra,Ca);
og_cdf_eq_G=equ(og_cdf_eq_G,Ra,Ca);
og_cdf_eq_B=equ(og_cdf_eq_B,Ra,Ca);

%Presentación de resultados
figure
subplot(3,3,2)
imshow(ima)
title('Imagen a ecualizar')

subplot(3,3,4)
bar(og_hist_a_R)
xlim([-10 265])
title('Histograma del Rojo')

subplot(3,3,5)
bar(og_hist_a_G)
xlim([-10 265])
title('Histograma del Verde')

subplot(3,3,6)
bar(og_hist_a_B)
xlim([-10 265])
title('Histograma del Azul')

subplot(3,3,7)
plot(og_cdf_a_R/max(og_cdf_a_R))
xlim([-10 265])
ylim([-0.1 1.1])
title('CDF del Rojo')

subplot(3,3,8)
plot(og_cdf_a_G/max(og_cdf_a_G))
xlim([-10 265])
ylim([-0.1 1.1])
title('CDF del Verde')

subplot(3,3,9)
plot(og_cdf_a_B/max(og_cdf_a_B))
xlim([-10 265])
ylim([-0.1 1.1])
title('CDF del Azul')

figure
subplot(3,3,2)
imshow(im1)
title('Imagen de referencia')

subplot(3,3,4)
bar(og_hist_R)
xlim([-10 265])
title('Histograma del Rojo')

subplot(3,3,5)
bar(og_hist_G)
xlim([-10 265])
title('Histograma del Verde')

subplot(3,3,6)
bar(og_hist_B)
xlim([-10 265])
title('Histograma del Azul')

subplot(3,3,7)
plot(og_cdf_R/max(og_cdf_R))
xlim([-10 265])
ylim([-0.1 1.1])
title('CDF del Rojo')

subplot(3,3,8)
plot(og_cdf_G/max(og_cdf_G))
xlim([-10 265])
ylim([-0.1 1.1])
title('CDF del Verde')

subplot(3,3,9)
plot(og_cdf_B/max(og_cdf_B))
xlim([-10 265])
ylim([-0.1 1.1])
title('CDF del Azul')


figure
subplot(3,3,1)
imshow(ima)
title('Imagen Original')

subplot(3,3,2)
imshow(im1)
title('Imagen de Referencia')

subplot(3,3,3)
imshow(im3)
title('Imagen Ecualizada')

subplot(3,3,4)
bar(og_hist_eq_R)
xlim([-10 265])
title('Histograma del Rojo')

subplot(3,3,5)
bar(og_hist_eq_G)
xlim([-10 265])
title('Histograma del Verde')

subplot(3,3,6)
bar(og_hist_eq_B)
xlim([-10 265])
title('Histograma del Azul')

subplot(3,3,7)
plot(og_cdf_eq_R/max(og_cdf_eq_R))
xlim([-10 265])
ylim([-0.1 1.1])
title('CDF del Rojo')

subplot(3,3,8)
plot(og_cdf_eq_G/max(og_cdf_eq_G))
xlim([-10 265])
ylim([-0.1 1.1])
title('CDF del Verde')

subplot(3,3,9)
plot(og_cdf_eq_B/max(og_cdf_eq_B))
xlim([-10 265])
ylim([-0.1 1.1])
title('CDF del Azul')
