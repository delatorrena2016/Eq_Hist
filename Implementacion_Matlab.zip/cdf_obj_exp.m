function z = cdf_obj_exp(l,m) %Función cdf_obj_exp para crear una distribución exponencial parametrizada

for i=1:256
      z(i)=m+exp(-l*i);
end