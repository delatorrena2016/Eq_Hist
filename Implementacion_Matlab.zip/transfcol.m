function t = transfcol(imagen,nf,R,C) %Función transfcol para hacer transformación de imagenes a color
                                      %respecto a una cdf dada
for l=1:3 %Por cada color: R,G,B
for k=0:255 %Por cada nivel de intensidad
    for i=1:R %Recorremos la imagen por filas
    for j=1:C %Recorremos la imagen por columnas
        if imagen(i,j,l)==k  %Si el valor de la intensidad en el pixel actual es igual al valor k entonces
           n_imagen(i,j,l)=nf(l,k+1); %El valor de la imagen nueva es el de la cdf dada para esa intensidad
        
        end
    end
    end
end
end
t=n_imagen;