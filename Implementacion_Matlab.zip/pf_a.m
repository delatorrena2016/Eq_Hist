close all
clear all
clc

im=imread('puente.jpg'); %Cargamos la imagen a ecualizar
im2=im2gray(im); %Convertimos la imagen a escala de grises

R=size(im2,1); %Calculamos las dimensiones de la imagen
C=size(im2,2);

og_hist=histog(im2,R,C); %Utilizamos la función para calcular el histograma
og_cdf=cudf(og_hist); %Utilizamos la función para calcular la CDF
c=equ(og_cdf,R,C); %Ecualizamos la CDF con la función Equ
og_cdf=og_cdf/(R*C); %Ajustamos la CDF de 0-1

im3=transf(im2,c,R,C); %Aplicamos la transformación (ecualización) de la imagen con la CDF ecualizada
im3=uint8(im3); %Convertimos a uint8 para que se visualice como imagen

new_hist=histog(im3,R,C); %Calculamos el histograma y el cdf de la imagen ecualizada
new_cdf=cudf(new_hist)/(R*C); %Ajustados la CDF de 0-1

%Presentación de resultados
figure
subplot(3,2,1)
imshow(im2)
title('Imagen original');

subplot(3,2,2)
imshow(im3)
title('Imagen ecualizada')

subplot(3,2,3)
bar(og_hist)
xlim([-10 265])
title('Histograma Original')

subplot(3,2,5)
plot(og_cdf)
xlim([-10 265])
ylim([-0.1 1.1])
title('CDF Original')

subplot(3,2,4)
bar(new_hist)
xlim([-10 265])
title('Histograma nuevo')

subplot(3,2,6)
plot(new_cdf)
xlim([-10 265])
ylim([-0.1 1.1])
title('CDF Nueva')

