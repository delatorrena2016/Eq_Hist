function z = cdf_obj_norm(mu,sig) %Función cdf_obj_norm para crear una distribución normal parametrizada
 
  for i=1:256
      z(i)=normpdf(i,mu,sig);
  end
