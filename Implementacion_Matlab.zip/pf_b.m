close all
clear all
clc

im=imread('puente.jpg'); %Cargamos la imagen a ecualizar
im2=im2gray(im); %Convertimos la imagen a escala de grises

R=size(im2,1); %Calculamos las dimensiones de la imagen
C=size(im2,2);

og_hist=histog(im2,R,C); %Utilizamos la función para calcular el histograma de la imagen
og_cdf=cudf(og_hist); %Utilizamos la función para calcular la CDF de la imagen

prueba=cdf_obj_exp(0.015,0.02); %Generamos la distribución objetivo, seleccionamos entre normal y exponencial
%prueba=cdf_obj_norm(128,45);

cdf_prueba=cudf(prueba); %Calculamos la CDF objetivo
cdf_prueba_norm=(cdf_prueba*max(og_cdf))/max(cdf_prueba); %Normalizamos la CDF objetivo

cdf_prueba_eq=equ(cdf_prueba_norm,R,C);  %Ecualizamos las dos CDFs para poder hacer matching
cdf_og_eq=equ(og_cdf,R,C);

AV=histmatch(cdf_og_eq,cdf_prueba_eq); %Calculamos la CDF de matching con la función histmatch

im3=transf(im2,AV,R,C); %Transformamos la imagen original con la CDF de matching
im3=mat2gray(im3); %Convertimos los valores a [0 1]
im4=255*im3; %Escalamos a [0-255]
im4=uint8(im4); %Convertimos a uint8 para visualizar como imagen

new_hist=histog(im4,R,C); %Calculamos el histograma y CDF de la nueva imagen ecualizada
new_cdf=cudf(new_hist);



%Presentación de resultados
figure
subplot(3,3,1)
imshow(im2)
title('Imagen original');

subplot(3,3,3)
imshow(im4)
title('Imagen ecualizada')

subplot(3,3,4)
bar(og_hist)
xlim([-10 265])
title('Histograma Original')

subplot(3,3,7)
plot(og_cdf/max(og_cdf))
xlim([-10 265])
ylim([-0.1 1.1])
title('CDF Original')

subplot(3,3,6)
bar(new_hist)
xlim([-10 265])
title('Histograma nuevo')

subplot(3,3,9)
plot(new_cdf/max(new_cdf))
xlim([-10 265])
ylim([-0.1 1.1])
title('CDF Nueva')

subplot(3,3,5)
bar(prueba)
xlim([-10 265])
title('Histograma objetivo')

subplot(3,3,8)
plot(cdf_prueba/max(cdf_prueba))
xlim([-10 265])
ylim([-0.1 1.1])
title('CDF Objetivo')

