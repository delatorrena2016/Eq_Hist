function v = cudf(hist) %Función cudf para calcular la CDF de un histograma
    v = cumsum(hist); %Suma acumulada del histograma