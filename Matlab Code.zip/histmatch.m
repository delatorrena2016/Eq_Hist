function y=histmatch(cdf1,cdfref) %Función histmatch para realizar el pareo de histogramas

for idx=1:256  %Por cada intensidad de gris inicial (G1)
    [~,ind]=min(abs(cdf1(idx)-cdfref)); %Buscamos la intensidad de gris (G2) que mapea a la CDF objetivo
    y(idx)=ind-1;                       %mediante el índice de esta [0-255] y se agrega a la nueva CDF (y)
end
