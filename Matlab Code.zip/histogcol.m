function y = histogcol(imagen, R, C) %Función histogcol para calcular histogramas de imagenes RGB

hi=zeros(3,256); %En esta matriz se guardarán los histogramas por color

for l=1:3 %Por cada color: R,G,B
for k=0:255 %Por cada nivel de intensidad
    for i=1:R %Recorremos la imagen por filas
    for j=1:C %Recorremos la imagen por columnas
        if imagen(i,j,l)==k %Si el valor de intensidad del pixel actual es igual a k entonces
            hi(l,k+1)=hi(l,k+1)+1;   %el histograma suma un 1 a ese valor de intensidad
        end
    end
    end
end
end

y=hi;