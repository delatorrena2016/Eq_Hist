function t = transf(imagen,nf,R,C) %Función transf para hacer transformación de imagenes a escala
                                   %de grises respecto a una cdf dada
for k=0:255 %Por cada nivel de intensidad
    for i=1:R %Recorremos la imagen por filas
    for j=1:C %Recorremos la imagen por columnas
        if imagen(i,j)==k  %Si el valor de la intensidad en el pixel actual es igual al valor k entonces
            n_imagen(i,j)=nf(k+1); %El valor de la imagen nueva es el de la cdf dada para esa intensidad
        end
    end
    end
end
t=n_imagen;