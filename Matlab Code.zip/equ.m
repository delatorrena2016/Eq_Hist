function z = equ(hist,M,N) %Función equ para ecualizar CDFs

for i=1:256 %Por cada nivel de intensidad
     t(i)=ceil(((hist(i)-min(hist))*255)/((M*N)-min(hist))); %Utilizamos la fórmula general
end                                                          %para ecualización de histograma

 z=t;