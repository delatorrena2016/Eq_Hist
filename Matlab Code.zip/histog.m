function y = histog(imagen, R, C) %Función histog para calcular histograma de una imagen a escala de grises

hi=zeros(1,256); %En este vector se guardará el histograma de la imagen
for k=0:255 %Por cada nivel de intensidad
    for i=1:R %Recorremos la imagen por filas
    for j=1:C %Recorremos la imagen por columnas
        if imagen(i,j)==k %Si el valor de la intensidad en el pixel actual es igual al valor k entonces
            hi(k+1)=hi(k+1)+1;  %el histograma suma un 1 a ese valor de intensidad
        end
    end
    end
end

y=hi;